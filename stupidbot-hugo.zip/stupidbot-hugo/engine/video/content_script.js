function getVideos(){

	let links = document.links;
	var videoLinks = [];
	for(let i = 0; i < links.length; i++){
		let link = links[i];
		if(link.getAttribute('href').includes('v=') && link.innerText != ''){
			
			videoLinks.push(link);
		}
	}

	let parents = [];

	for (var i = videoLinks.length - 1; i >= 0; i--) {
		parents.push(videoLinks[i].parentElement.parentElement.parentElement.innerHTML);
	}

	return parents;
}

function scrollBottom(){
	window.scrollTo(0, document.body.scrollHeight);
}

function handleScrolling() { 
	scrollBottom();

	if(document.getElementById('browse_end_of_results_footer') !== null){
		
		var videoLinks = getVideos();

		console.log(videoLinks); 
		chrome.runtime.sendMessage({command: 'videoLinks', data: videoLinks});
	}
	else{ 
		setTimeout(handleScrolling, 1000);
	}
}


