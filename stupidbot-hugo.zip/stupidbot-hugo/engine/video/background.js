function video_scraper(data){
	var keywords = data.keywords.split("\n");
	console.log(keywords);

	resetData();

	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];

    chrome.storage.local.set({keywords: keywords}, function(){
    	scrape_videos();
    });
  });
	
}

function scrape_videos(){
	chrome.storage.local.get({keywords: []}, function(result){
    var keywords = result.keywords;
    console.log(keywords.length);

    if(keywords.length > 0){
      var keyword = keywords.shift();

      setHeading('Scraping in progress...');
      setStatus('Scraping video: ' + keyword);
      chrome.storage.local.set({keywords: keywords}, function(){
      	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
					var url = 'https://www.facebook.com/search/videos/?q=' + keyword;
				  var tab = tabs[0];
					chrome.tabs.update(tab.id, {url});
				  scrollBottom(tab);
				});
      });
    }
    else{
    	chrome.runtime.sendMessage({
        command: 'markAsDone',
        params: ''
      });
    }

  });
}

chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.command == "videoLinks"){
  	var videoLinks = request.data;

  	chrome.storage.local.get({videoNodes: []}, function(result){
  		var videoNodes = result.videoNodes;
  		videoNodes = videoNodes.concat(videoLinks);

  		chrome.storage.local.set({videoNodes: videoNodes}, function(){
  			parseVideos();
  		});
  	});
  }
});

function parseVideos(){
	chrome.storage.local.get({videoNodes: []}, function(result){
    var videoNodes = result.videoNodes;

    if(videoNodes.length > 0){
      var videoNode = videoNodes.shift();
      setHeading('Scraping in progress...');
      chrome.storage.local.set({videoNodes: videoNodes}, function(){

				var video = {};
				var el = $(videoNode);

				var url = el.find('a').attr('href');
				var texts = [];

				el.find('*').each(function(){

					let text = $(this).text();

					if($(this).children().length == 0){


						if(text !== '' 
							&& !text.includes('play') 
							&& !text.includes(" · ") 
							&& !text.includes("PERTUNJUKAN") 
							){
							texts.push($(this).text());
						}
					}
				})

				texts = _.uniq(texts);


				video.id = getParams(url).v;

				video.texts = _.compact(texts); 
				video.duration = video.texts.shift();
				video.title = video.texts.shift(); 
				video.title = _.startCase(_.toLower(video.title)); 
				video.created_at = video.texts.pop();
				video.creator = video.texts.pop();

			  setStatus('Scraping video: ' + video.title);

				var keyword = video.title;

				image_search({ query: keyword, moderate: true, retries: 2, iterations: 1 }).then(results => {
			    setStatus('Got ' + results.length + ' images');
			    var recipe = video;
			    recipe.images = results;

			    getSentences(keyword, function(sentences){
			      setStatus('Got ' + sentences.length + ' article sentences for ' + keyword);
			      recipe.sentences = sentences;

			      related_keywords(keyword, function(related_keywords){
			        recipe.related_keywords = related_keywords;

			        save_recipe(recipe, function(){
			          refreshDownloadBtn();
			          console.log(recipe); 

			          console.log(videoNodes.length);

			          parseVideos();
			        });
			      });


			    });
			  }) 

      });
    }
    else{
    	scrape_videos();
    }

	});
}

function scrollBottom(tab){

	chrome.tabs.onUpdated.addListener(async function onUpdated(tabId, info) {
		console.log(info);	
    if (tabId === tab.id && info.status === 'complete') {

    	await sleep(3000);
      

      chrome.tabs.executeScript(tab.id, {
        code: 'handleScrolling();'
      },
      function (result) {});
  	} 
  });
}

function getParams(url) {
	var params = {};
	var parser = document.createElement('a');
	parser.href = url;
	var query = parser.search.substring(1);
	var vars = query.split('&');
	for (var i = 0; i < vars.length; i++) {
		var pair = vars[i].split('=');
		params[pair[0]] = decodeURIComponent(pair[1]);
	}
	return params;
}
