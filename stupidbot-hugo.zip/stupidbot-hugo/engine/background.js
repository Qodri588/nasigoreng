function resetData(){
	chrome.storage.local.set({keywords: []});
  chrome.storage.local.set({paging_urls: []});
  chrome.storage.local.set({urls: []});
  chrome.storage.local.set({recipes: []});
  chrome.storage.local.set({posts: []});
  chrome.storage.local.set({videoNodes: []});
}

function slugify(string) {
  const a = 'àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż·/_,:;'
  const b = 'aaaaaaaaaacccddeeeeeeeegghiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz------'
  const p = new RegExp(a.split('').join('|'), 'g')

  return string.toString().toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with -  
    .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
    .replace(/&/g, '-and-') // Replace & with 'and'
    .replace(/[^\w\-]+/g, '') // Remove all non-word characters
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
    .replace(/^-+/, '') // Trim - from start of text
    .replace(/-+$/, '') // Trim - from end of text
}


function randomDate(start, end) {
  
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function calculatePostCount(){
	chrome.storage.local.get({recipes: []}, function(result){
		$('#post_count').text(result.recipes.length);
	    
	});
}

function parseHeader(){ 
  var path = window.location.pathname;

  $('#engine option').each(function(){
    var target = $(this).val();

    if(path.includes(target)){
      $(this).attr('selected', 'selected');
    }
  });
}

function parseNav(){
	var path = window.location.pathname.replace('/', '');

	$('#navs a').each(function(){
		var href = $(this).attr('href').replace('.html', '');

		if(path.includes(href)){
			$(this).addClass('disabled');
		}
	});
}

Array.prototype.unique = function() {
  return this.filter(function (value, index, self) { 
    return self.indexOf(value) === index;
  });
}

Array.prototype.sample = function(){
  return this[Math.floor(Math.random()*this.length)];
}

Array.prototype.divideInto = function(n){
	var items = this;
	var results = [];
	const wordsPerLine = Math.ceil(items.length / n);

	for (let line = 0; line < n; line++) {
		var result = [];
		for (let i = 0; i < wordsPerLine; i++) {
			const value = items[i + line * wordsPerLine];
			if (value == undefined) continue; //avoid adding "undefined" values
			result.push(value);
		}
		console.log(result);

		results.push(result);
	}

	return results;
}

function set(id, string){
  show(id);
  $('#'+id).text(string);
}

function setStatus(status){
  chrome.storage.local.set({status: status});
  chrome.runtime.sendMessage({
      command: "setStatus", 
      params: status
  });
  notify();
}

function setHeading(heading){
  chrome.storage.local.set({heading: heading});
  chrome.runtime.sendMessage({
      command: "setHeading", 
      params: heading
  });

  notify();
}

//notify
function notify(){
  return false;
  //chrome.storage.local.get({heading: ''}, function(result){
    //var heading = result.heading;

    //chrome.storage.local.get({status: ''}, function(result){
      //var status = result.status;
      
      //var notification = new Notification(heading, {
        //icon: '/images/logo-dojo.png',
        //body: status
      //});

    //});

  //});
}

function refreshDownloadBtn(){
  chrome.runtime.sendMessage({
      command: "refreshDownloadBtn"
  });
}

function showLoading(){
	$('#loading').removeClass('d-none');
}

function hideLoading(){
	$('#loading').addClass('d-none');
}

function showPublishButton(){
	$('#publish_btn').removeClass('d-none');
}

function hidePublishButton(){
	$('#publish_btn').addClass('d-none');
}

function showForm(){
	$('#form').removeClass('d-none');
}

function hideForm(){
	$('#form').addClass('d-none');
}

function show(id){
	$('#'+id).removeClass('d-none');
}

function hide(id){
	$('#'+id).addClass('d-none');
}

function xmlToJson(xml) {
  // Create the return object
  var obj = {};

  if (xml.nodeType == 1) {
    // element
    // do attributes
    if (xml.attributes.length > 0) {
      obj["@attributes"] = {};
      for (var j = 0; j < xml.attributes.length; j++) {
        var attribute = xml.attributes.item(j);
        obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
      }
    }
  } else if (xml.nodeType == 3) {
    // text
    obj = xml.nodeValue;
  }

  // do children
  // If all text nodes inside, get concatenated text from them.
  var textNodes = [].slice.call(xml.childNodes).filter(function(node) {
    return node.nodeType === 3;
  });
  if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
    obj = [].slice.call(xml.childNodes).reduce(function(text, node) {
      return text + node.nodeValue;
    }, "");
  } else if (xml.hasChildNodes()) {
    for (var i = 0; i < xml.childNodes.length; i++) {
      var item = xml.childNodes.item(i);
      var nodeName = item.nodeName;
      if (typeof obj[nodeName] == "undefined") {
        obj[nodeName] = xmlToJson(item);
      } else {
        if (typeof obj[nodeName].push == "undefined") {
          var old = obj[nodeName];
          obj[nodeName] = [];
          obj[nodeName].push(old);
        }
        obj[nodeName].push(xmlToJson(item));
      }
    }
  }
  return obj;
}

function containsBadWord(string){
  var badwords = [
    'read more',
    'email',
    'facebook',
    'twitter',
    'pricing',
    'shipping',
    'pinterest',
    'offer',
    'shop'
  ];

  for (var i = badwords.length - 1; i >= 0; i--) {
    
    if(string.toLowerCase().includes(badwords[i])){
      console.log(badwords[i], string, string.toLowerCase().includes(badwords[i]));
      return true;
    }
  }

  return false;
}

async function getSentences(query, callback){
  await sleep(1000);

  fetch('https://duckduckgo.com/html/?q=' + query)
  .then((result) => { return result.text() })
  .then((result) => { 
    var doc = new DOMParser().parseFromString(result, 'text/html');
    var elements = doc.querySelectorAll('.result__snippet');
    var results = '';

    elements.forEach( el => { 
      results = results + ' ' + el.innerText;
    });

    var raw_sentences = results.replace(/([.?!])\s*(?=[A-Z])/g, "$1|").split("|");
    var sentences = [];

    raw_sentences.forEach(function(string, index){
      string = string.trim();
      string = string.replace(/[.]{2,}/g, '.');
      string = string.replace('...', '.');
      string = string.replace('..', '.');
      string = string.replace(' .', '.');
      string = string.trim();
      if(string.split(' ').length > 5 
        && /\d/.test(string) === false 
        && containsBadWord(string) === false
        ){
        
        console.log(index, string.split(' ').length, /\d/.test(string),  containsBadWord(string));
        sentences.push(string);
      }
    });

    console.log(sentences);

    callback(sentences);
  });
}

function save_recipe(recipe, callback){
  chrome.storage.local.get({ recipes: []}, function(result){
    var recipes = result.recipes;
    recipes = recipes.concat([recipe]);
    
    chrome.storage.local.set({recipes: recipes}, function(){
      callback();
    });
  });
}

async function related_keywords(keyword, callback){
  await sleep(1000);
  fetch('http://suggestqueries.google.com/complete/search?client=chrome&q=' + keyword).then(resp => {
    if (!resp.ok) {
      return null;
    }
    
    return  resp.text();

  }).then(terms => {

    if(terms == null){
      callback([]);
    }
    else{

      let parsed = JSON.parse(terms);

      if(!_.isEmpty(parsed[1])){
        let keywords = parsed[1];
        callback(keywords);
      }
      else{
        callback([]); 
      }
    }

  });
}