const { image_search , image_search_generator } = require('duckduckgo-images-api')

window.image_search = image_search;

window.image_scraper = function (data){
	var keywords = data.keywords.split("\n");
	console.log(keywords);

	resetData();

	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];

    chrome.storage.local.set({keywords: keywords}, function(){
    	scrape_images();
    });
  });
}

window.resume_image = function(){
  console.log('resume recipe');

  scrape_images(); 
}


function scrape_images(){
  chrome.storage.local.get({keywords: []}, function(result){
    var keywords = result.keywords;
    console.log(keywords.length);

    if(keywords.length > 0){
      var keyword = keywords.shift();

      setHeading('Scraping in progress...');
      setStatus('Scraping image: ' + keyword);
      chrome.storage.local.set({keywords: keywords}, function(){
        image_search({ query: keyword, moderate: true, retries: 2, iterations: 1 }).then(results => {
          setStatus('Got ' + results.length + ' images');
          var recipe = {};
          recipe.title = _.startCase(_.toLower(keyword)); 
          recipe.images = results;

          getSentences(keyword, function(sentences){
            setStatus('Got ' + sentences.length + ' article sentences');
            recipe.sentences = sentences;

            related_keywords(keyword, function(related_keywords){
              recipe.related_keywords = related_keywords;

              save_recipe(recipe, function(){
                refreshDownloadBtn();
                console.log(recipe);
                scrape_images(); 
              });
            });


          });
        }) 
      });
    }
    else{
      chrome.runtime.sendMessage({
        command: 'markAsDone',
        params: ''
      });
    }

  });
}



