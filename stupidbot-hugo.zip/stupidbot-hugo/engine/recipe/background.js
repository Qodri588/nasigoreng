function recipe_scraper(data){
	var keywords = data.keywords.split("\n");
	var region = data.region;
	console.log(keywords);

	resetData();

	chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];

    chrome.storage.local.set({keywords: keywords}, function(){
    	chrome.storage.local.set({region: region}, function(){
        scrapeSearchResult(tab);
      });
    });
  });
}

async function scrapeSearchResult(tab) {
  chrome.storage.local.get({ keywords: []}, function(result){
    var keywords = result.keywords;

    if(keywords.length > 0){
      var keyword = keywords.shift();

      chrome.storage.local.set({keywords: keywords}, function(){
        chrome.storage.local.get({region: 'id/cari'}, function(result){
          var url = 'https://cookpad.com/'+ result.region +'/' + keyword;
          scrapeKeyword(tab, url);
        });
      });
    }
    else{
      chrome.runtime.sendMessage({
	      command: 'markAsDone',
	      params: ''
  	  });
    }
  });
  
}

async function scrapeKeyword(tab, url){
  await goToUrl(tab, url);
}

function goToUrl(tab, url) {
  chrome.tabs.update(tab.id, {url});
  return new Promise(resolve => {
    chrome.tabs.onUpdated.addListener(function onUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        setStatus(url);

        scrapeIfNotBlocked(function(){
          setHeading('Scraping initial pages');
          // get total recipes
          chrome.tabs.executeScript(tab.id, {
            // code: 'document.documentElement.outerHTML;'
            code: 'getPageUrls();'
          }, function (result) {
            var new_urls = result[0];
            chrome.storage.local.get({ paging_urls: []}, function(result){
              var paging_urls = result.paging_urls;
              paging_urls = paging_urls.concat(new_urls);
              
              chrome.storage.local.set({paging_urls: paging_urls}, function () {
                // you can use strings instead of objects
                // if you don't  want to define default values
                chrome.storage.local.get('paging_urls', function (result) {
                    console.log(result.paging_urls);
                    scrapePaginations(tab);
                    resolve();
                });
              });
            });
          });
        }, function(){
          unblock(url, function(){
            goToUrl(tab, url);
          });
        });
      }
    });
  });
}

function scrapeIfNotBlocked(resolve, reject){
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];
    chrome.tabs.executeScript(tab.id, { code: 'isBlocked()' }, function(result){
      var blocked = result[0];
      console.log('blocked:' + blocked);

      if(!blocked){
        resolve();
      }
      else{
        reject();
      }

    });
  });
  
}

async function scrapePaginations(tab){
  chrome.storage.local.get('paging_urls', function (result) {
      var paging_urls = result.paging_urls;
      console.log(paging_urls);

      var stop = paging_urls.length == 0 ? true : false;

      if(stop){
        scrapeSearchResult(tab);
      }
      else{
        var paging_url = paging_urls.shift();

        chrome.storage.local.set({paging_urls: paging_urls}, function(){

          processPaginationUrls(paging_url, tab, stop);
        });
      }      
  });
}

async function processPaginationUrls(paging_url, tab, stop){
  await scrapePagination(paging_url, tab, stop);
}

function scrapePagination(paging_url, tab, stop) {
  chrome.tabs.update(tab.id, {url: paging_url});

  return new Promise( resolve => {
      chrome.tabs.onUpdated.addListener(function onUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        setStatus(paging_url);

        scrapeIfNotBlocked(function(){
          setHeading('Scraping pagination links');


          // get total recipes
          chrome.tabs.executeScript(tab.id, {
            // code: 'document.documentElement.outerHTML;'
            code: 'getRecipeUrls();'
          }, function (result) {
            var new_urls = result[0];
            chrome.storage.local.get({ urls: []}, function(result){
              var urls = result.urls;
              urls = urls.concat(new_urls);

              urls = urls.unique();
              
              chrome.storage.local.set({urls: urls}, function () {
                // you can use strings instead of objects
                // if you don't  want to define default values
                chrome.storage.local.get('urls', function (result) {
                    console.log(result.urls);
                    scrapeUrls(tab);
                    resolve();
                });
              });
            });
          });
        }, function(){
          unblock(paging_url, function(){
            scrapePagination(paging_url, tab, stop);
          })
        });

        
      }
    });
  });
}

async function scrapeUrls(tab){
  chrome.storage.local.get('urls', function (result) {
      var urls = result.urls;
      console.log(urls.length);
      var url = urls.shift();

      var stop = urls.length == 0 ? true : false;

      chrome.storage.local.set({urls: urls}, function(){
        processUrls(url, tab, stop, 0);
      });

  });
}

async function processUrls(url, tab, stop, duration){
  await sleep(duration);
  await scrapeUrl(url, tab, stop);
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function scrapeUrl(url, tab, stop) {
  chrome.tabs.update(tab.id, {url: url});
  
  return new Promise( resolve => {
      chrome.tabs.onUpdated.addListener(function onUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);
        setStatus(url);

        chrome.tabs.executeScript(tab.id, { code: 'isBlocked()' }, function(result){
          var blocked = result[0];
          console.log('blocked:' + blocked);

          if(blocked){
            setHeading('Blocked, let\'s fight the PerimeterX bot');
            unblock(url, function(){
              processUrls(url, tab, stop, 5000);
            });
          }
          else{
            setHeading('Scraping in progress...');
            // get total recipes
            chrome.tabs.executeScript(tab.id, {
              // code: 'document.documentElement.outerHTML;'
              code: 'getRecipe();'
            }, function (result) {
              // get sentences 
              
              console.log(result[0]);

              getSentences(result[0].title, function(sentences){
                setStatus('Got ' + sentences.length + ' article sentences');
                var recipe = result[0];

                if(recipe.image){
                  recipe.sentences = sentences;
                  save_recipe(recipe, function(){
                    refreshDownloadBtn();
                    
                    if(stop){
                      scrapePaginations(tab);
                      resolve();
                    }
                    else{
                      scrapeUrls(tab);
                    }

                  });

                }
                else{
                  setStatus('Recipe does not have an image, skipping...');
                  
                  if(stop){
                    scrapePaginations(tab);
                    resolve();
                  }
                  else{
                    scrapeUrls(tab);
                  }
                }
              });

            });
          }

        });
      }
    });
  });
}

async function unblock(url, callback){
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];
    unblockTab(tab, url, callback);
  });
}

async function unblockTab(tab, url, callback){
  setHeading('Blocked, let\'s fight the PerimeterX bot');
  await sleep(5000);
  await sleep(10000);

  await _reload(url, tab);
  await sleep(5000);
  await clearCookies();

  await _reload(url, tab);
  await sleep(5000);
  await setNewCookie();


  await sleep(5000);
  await _reload(url, tab);

  await sleep(5000);

  callback();
}

function _reload(url, tab){
  setStatus('_reloading...' + url);
  chrome.tabs.update(tab.id, {url: url});

  return new Promise(resolve => {
    chrome.tabs.onUpdated.addListener(function onUpdated(tabId, info) {
      if (tabId === tab.id && info.status === 'complete') {
        chrome.tabs.onUpdated.removeListener(onUpdated);

        chrome.tabs.executeScript(tab.id, { code: 'isBlocked()' }, function(result){
          var blocked = result[0];
          console.log('blocked:' + blocked);

          if(blocked){
            var usages = ['use'];
            var weapons = ["Magic Wand", "Power Treads", "Wraith Band", "Phase Boots", "Blink Dagger", "Black King Bar", "Aghanim's Scepter", "Tranquil Boots", "Arcane Boots", "Null Talisman", "Quelling Blade", "Bracer", "Enchanted Mango", "Blade Mail", "Dust of Appearance", "Desolator", "Aether Lens", "Observer and Sentry Wards", "Boots of Speed", "Force Staff", "Eul's Scepter of Divinity", "Bottle", "Manta Style", "Monkey King Bar", "Glimmer Cape", "Soul Ring", "Wind Lace", "Abyssal Blade", "Clarity", "Boots of Travel", "Maelstrom", "Shadow Blade", "Diffusal Blade", "Pipe of Insight", "Observer Ward", "Sentry Ward", "Orb of Venom", "Skull Basher", "Iron Branch", "Spirit Vessel", "Ogre Axe", "Magic Stick", "Smoke of Deceit", "Mjollnir", "Mask of Madness", "Guardian Greaves", "Paladin Sword", "Ghost Scepter", "Battle Fury", "Assault Cuirass", "Ring of Basilius", "Titan Sliver", "Daedalus", "Vambrace", "Echo Sabre", "Radiance", "Morbid Mask", "Vampire Fangs", "Healing Salve", "Headdress", "Orb of Destruction", "Staff of Wizardry", "Mind Breaker", "Quickening Charm", "Philosopher's Stone", "Vladmir's Offering", "Butterfly", "Rod of Atos", "Orchid Malevolence", "Essence Ring", "Heaven's Halberd", "Tango", "Hurricane Pike", "Heart of Tarrasque", "Telescope", "Dragon Scale", "Imp Claw", "Spider Legs", "Sange and Yasha", "Ring of Aquila", "Hand of Midas", "Faded Broach", "Urn of Shadows", "Keen Optic", "Blight Stone", "Pupil's Gift", "Grove Bow", "Linken's Sphere", "Dragon Lance", "Crimson Guard", "Mithril Hammer", "Scythe of Vyse", "The Leveller", "Trusty Shovel", "Spell Prism", "Eye of Skadi", "Kaya", "Satanic", "Nether Shawl", "Silver Edge", "Point Booster", "Crystalys", "Arcane Ring", "Enchanted Quiver", "Clumsy Net", "Timeless Relic", "Minotaur Horn", "Prince's Knife", "Vanguard", "Havoc Hammer", "Mekansm", "Ninja Gear", "Magic Lamp", "Ethereal Blade", "Craggy Coat", "Lotus Orb", "Illusionist's Cape", "Repair Kit", "Greater Faerie Fire", "Yasha", "Bloodstone", "Shiva's Guard", "Hood of Defiance", "Ocean Heart", "Broom Handle", "Armlet of Mordiggian", "Platemail", "Flicker", "Bloodthorn", "Buckler", "Veil of Discord", "Ironwood Tree", "Witless Shako", "Aeon Disk", "Aegis of the Immortal", "Ultimate Orb", "Ring of Regen", "Poor Man's Shield", "Blade of Alacrity", "Ring of Tarrasque", "Ring of Protection", "Octarine Core", "Javelin", "Hyperstone", "Gem of True Sight", "Iron Talon", "Drum of Endurance", "Medallion of Courage", "Perseverance", "Moon Shard", "Cloak", "Solar Crest", "Refresher Orb", "Cheese", "Void Stone", "Quarterstaff", "Yasha and Kaya", "Faerie Fire", "Vitality Booster", "Mystic Staff", "Divine Rapier", "Necronomicon (level 3)", "Crown", "Chainmail", "Meteor Hammer", "Sange", "Circlet", "Helm of the Dominator", "Sage's Mask", "Shadow Amulet", "Infused Raindrops", "Dagon (level 5)", "Belt of Strength", "Gauntlets of Strength", "Demon Edge", "Reaver", "Gloves of Haste", "Energy Booster", "Oblivion Staff", "Ring of Health", "Broadsword", "Robe of the Magi", "Claymore", "Mantle of Intelligence", "Boots of Travel", "Slippers of Agility", "Tango (Shared)", "Eaglesong", "Kaya and Sange", "Tome of Knowledge", "Nullifier", "Band of Elvenskin", "Holy Locket", "Talisman of Evasion", "Helm of Iron Will", "Dagon", "Soul Booster", "Blades of Attack", "Stygian Desolator", "Mirror Shield", "Apex", "Pirate Hat", "Sacred Relic", "Fallen Sky", "Necronomicon", "Book of the Dead", "Dagon (level 2)", "Dagon (level 3)", "Ex Machina", "Woodland Striders", "Seer Stone", "Force Boots", "Ballista", "Dagon (level 4)", "Refresher Shard", "Royal Jelly", "Trident", "Necronomicon (level 2)", "Mango Tree", "Aghanim's Blessing", "Town Portal Scroll", "River Vial: Dry", "Dragon Lance", "Recipe: Aether Lens"];
            setHeading('Let\'s ' + usages.sample() + ' ' + weapons.sample());
          }
          else{
            setHeading('That\'s great. You win the fight!' );
          }

          resolve();
        });
      }
    });
  });
}

function clearCookies(){
  setStatus('clearing all cookies');
  return new Promise(resolve => {
    chrome.cookies.getAll({domain: "cookpad.com"}, function(cookies) {
      for(var i=0; i<cookies.length;i++) {
        var index = i;

        chrome.cookies.remove({url: "https://" + cookies[i].domain  + cookies[i].path, name: cookies[i].name}, function(){
          if(index == cookies.length-1){
            console.log(index, cookies.length-1, 'fired');
            resolve();
          }
        });
      }
    });
  });
  
}

function setNewCookie(){
  setStatus('setting new cookie');
  return new Promise(resolve => {
    chrome.cookies.remove({url: 'https://cookpad.com', name: '_pxff_rf'}, function(){
      chrome.cookies.set({
      url: 'https://cookpad.com/', 
      name: '_pxff_rf', 
      value: '0',
      path: '/',
      expirationDate: (new Date().getTime()/1000) + 3600
      }, function(){
        resolve();
      });
    });
  });
}

function resume_recipe(){
  chrome.tabs.query({active: true, currentWindow: true}, function(tabs) {
    var tab = tabs[0];
    chrome.storage.local.get({urls: []}, function(result){
      if(result.urls.length > 0){
        scrapeUrls(tab);
      }
      else{
        chrome.storage.local.get({paging_urls: []}, function(result){
          if(result.paging_urls.length > 0){
            console.log(result.paging_urls.length);
            scrapePaginations(tab);
          }
          else{
            chrome.storage.local.get({keywords: []}, function(result){
              if(result.keywords.length > 0){
                console.log(result.keywords.length);
                scrapeSearchResult(tab);
              }
            });
          }
        });
      }
    });
  });
}