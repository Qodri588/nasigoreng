$(function(){
	$('#start').click(function(e){
		e.preventDefault();
		var data = $('form').serializeJSON();
		
		hide('resume_btn');
		show('loading');
    hide('form-keywords');

    set('title', 'Scraping in progress...');
    data.keywords = data.keywords.trim();

    if(data.keywords != ''){

  		chrome.runtime.sendMessage({command: 'scrape', data: data});
    }
    else{

      set('status', 'Please supply some keywords');
    }
	});
});