$(function(){
	$('#publish').click(function(){
		show('loading');
		setHeading('Downloading...');
		chrome.storage.local.get({posts: []}, function(result){
			var posts = result.posts;
			var blob = new Blob([JSON.stringify(posts)], {type: "application/json"});
		    var url = URL.createObjectURL(blob);
		    chrome.downloads.download({
		      url: url,
		      filename: 'stupidbot-posts.json'
		    });
		});
	});
});