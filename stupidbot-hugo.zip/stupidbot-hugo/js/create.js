$(function(){
	engine(function(engine){
		$.get('/engine/'+ engine +'/create/title.html', function(title){
	  	$('input[name=title]').val(title);
	  });

	  $.get('/engine/'+ engine +'/create/content.html', function(content){
	  	$('textarea[name=content]').text(content);
	  });

	  $('#title i').text('(/engine/'+ engine +'/create/title.html)');
	  $('#content i').text('(/engine/'+ engine +'/create/content.html)');
	});
  
  $('#date_start').val(new Date(new Date().setFullYear(new Date().getFullYear() - 1)).toJSON().slice(0,10));
  $('#date_end').val(new Date().toJSON().slice(0,10));

  createPostEventListener();
  listenForRecreateBtn();

  loading(function(){
  	set('title', 'Post Creator');
  	chrome.storage.local.get({recipes: []}, function(result){
		
			if(result.recipes.length > 0){
				chrome.storage.local.get({posts: []}, function(result){
					console.log(result);
					if(result.posts.length > 0){
						hide('form');
						postFound();
					}
					else{
						postNotFound();
					}
				});
			}
			else{
				recipeNotFound();
			}
		})
  });
});


function postFound(){
	setHeading('Post data exists, do you want to publish?');

	showPublishButton();
	show('recreate_btn');
	setStatus('Click publish to continue or recreate to delete post data and start over');
	hide('loading');
}

function postNotFound(){
	show('form');
}

function recipeNotFound(){
	setHeading('No data found');
	hide('form');
	hidePublishButton();
	hide('recreate_btn');
	show('scrape_btn');
	setStatus('Please scrape data first');
	hide('loading');
}

function listenForRecreateBtn(){
	$('#recreate_btn').click(function(){
		chrome.storage.local.set({posts: []}, function(){

			showCreateForm();
		});
	});
}

function showCreateForm(){
	setHeading('Post creator');
		hide('loading');
		hide('publish_btn');
		hide('recreate_btn');
		hide('status');

		show('form');
}

function createPostEventListener(){
	$('#create_btn').click(function(){
		// reset posts first
		chrome.storage.local.set({posts: []}, function(){
			hideForm();
			setHeading('Please wait');
			setStatus('Creating posts...');

			var date_start = new Date($('#date_start').val());
			var date_end = new Date($('#date_end').val());
			var category = $('#category').val();

			showLoading();
	  	chrome.storage.local.get({recipes: []}, function(result){
		    if(result.recipes.length > 0){
		    	var recipes = result.recipes;

		    	// meta json

		    	loadTemplate(['title', 'content', 'json_ld', 'metas'], function(templates){
		    		var title = templates.title;
		    		var content = templates.content;
		    		var json_ld = templates.json_ld;
					var metas = templates.metas;
					// var metas = templates.footer;
			  		var posts = [];

			  		recipes.forEach(function(recipe, index){

			  			console.log(recipe);

			    		var post = {};
			    		post.title = ejs.render(title, {data: recipe, _: _, collect: collect});
			    		post.title = spintax.unspin(post.title);
					  	post.tags = [];

					  	recipe.related_keywords.forEach(function(related_keyword){
					  		var tag = {};
					  		tag.name = related_keyword;
					  		tag.slug = slugify(related_keyword);

					  		post.tags.push(tag);
					  	});

					  	function makeid(length) {
					  		var result           = '';
					  		var characters       = 'abcdefghijklmnopqrstuvwxyz0123456789';
					  		var charactersLength = characters.length;
					  		for ( var i = 0; i < length; i++ ) {
					  			result += characters.charAt(Math.floor(Math.random() * charactersLength));
					  		}
					  		return result;
					  	};

					  	uniq = makeid(3);

					  	post.date = moment(randomDate(date_start, date_end));
					  	
				  		post.content = ejs.render(content, {data: recipe, _: _, collect: collect, chance: chance, moment: moment});
				  		// console.log(content);

				  		post.content = spintax.unspin(post.content);

				  		post.metas = ejs.render(metas, {data: recipe, _: _, collect: collect, chance: chance, moment: moment, post: post});
						post.metas = spintax.unspin(post.metas);

						// post.footer = ejs.render(footer, {data: recipe, _: _, collect: collect, chance: chance, moment: moment, post: post});
						// post.footer = spintax.unspin(post.footer);

					  	post.date_blogger = post.date.toJSON();

					  	post.date_wp = moment(post.date).format('YYYY-MM-DD HH:mm:ss');
					  	// post.slug = slugify(index + ' ' + post.title);
					  	post.slug = slugify(post.title + ' ' + index + uniq);
					  	//post.slug = slugify(uniq + ' ' + index);
					  	post.category = category;
					  	post.category_slug = slugify(category);

					  	console.log(post, recipe);

					  	post.json_ld = ejs.render(json_ld, {data: recipe, _: _, collect: collect, chance: chance, moment: moment, post: post});
					  	posts.push(post);

			  		});

			  		chrome.storage.local.set({posts: posts}, function(){
			  			postFound();
			  		});
		    	});
		    }
		    else{
		    	setStatus('Data is empty, please scrape first');
		    }
		  });
		});
  });
}