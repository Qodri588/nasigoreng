function save_recipe(recipe, callback){
  chrome.storage.local.get({ recipes: []}, function(result){
    var recipes = result.recipes;
    recipes = recipes.concat([recipe]);
    
    chrome.storage.local.set({recipes: recipes}, function(){
      callback();
    });
  });
}

function download_recipes(){
  console.log('downloading...');
  chrome.storage.local.get({ recipes: []}, function(result){
    var recipes = result.recipes;

    var blob = new Blob([JSON.stringify(recipes)], {type: "application/json"});
    var url = URL.createObjectURL(blob);
    chrome.downloads.download({
      url: url,
      filename: 'recipes' + (new Date()).getTime() + '.json'
    });
    
  });
}