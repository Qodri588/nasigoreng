$(function(){
	$('#publish_blogger').click(function(){
		show('loading');
		setHeading('Downloading...');
		chrome.storage.local.get({posts: []}, function(result){
			$.get('templates/blogger.html', function(blogger){
				var xml = ejs.render(blogger, {posts: result.posts});

				var blob = new Blob([xml], {type: "application/xml"});
			    var url = URL.createObjectURL(blob);
			    chrome.downloads.download({
			      url: url,
			      filename: 'blogger-' + (new Date()).getTime() + '.xml'
			    });
			});
		});
	});
});