$(function(){
	$('#year').text(new Date().getFullYear());
	$('#header').load('/partials/header.html', function(){ parseHeader(); });
	$('#nav').load('/partials/nav.html', function(){ parseNav(); });
	$('#support').load('/partials/support.html');


  $(document).on('change', '#engine', function(e){
    e.preventDefault();
    var engine = $(this).find('option:selected').val();

    if(engine !== 'engine'){
      var confirmed = confirm('Switching engine will wipe all data, do you want to continue?');

      if(confirmed){
        chrome.storage.local.set({engine: engine}, function(){
          resetData();
          var url = '/engine/' + engine + '/scrape.html';
          window.location = url;
        });
      }
    }
    else{
      location.reload();
    }
  });

	$('.btn-back').click(function(){
		window.history.back();
	});

  $(document).on('click', '.reload', function(e){
    e.preventDefault();
    chrome.runtime.sendMessage({command: 'reload'});
  });

	calculatePostCount();

  chrome.runtime.onMessage.addListener(
    function(request, sender, sendResponse) {
      console.log(request);
      if (request.command != '') {
        if(request.params != '' && request.params != undefined){
          if(request.params.toLowerCase().includes('scraping')){
            markInProgress();
          }
          window[request.command](request.params);
        }
        else{
          window[request.command]();
        }
      }
    }
  );


  ifQueueExists(function(){
    toggle('Queue Exists, should we resume scraping?');
    $('#resume_btn').removeClass('d-none');
    $('#spinner').addClass('d-none');
    setStatus('Click restart if you want to start over');
  }, function(){
    if(window.location.pathname.includes('scrape')){

      toggle('Data found');
      setStatus('Create posts or click restart if you want to start over');
      $('#spinner').addClass('d-none');
      refreshDownloadBtn();
    }
  });

  $('#resume_btn').click(function(){
    setHeading('Scraping in progress');
    $('#resume_btn').addClass('d-none');
    $('#loading').removeClass('d-none');
    $('#spinner').removeClass('d-none');
    $('#create_btn').addClass('d-none');
    $('#spinner').removeClass('d-none');
    resume();
  });

  $('#restart_btn').click(function(){
    set('status', '');
    hide('restart_btn'); 
    hide('resume_btn');
    setStatus('');
    resetData();
    engine(function(engine){

      toggle(engine.charAt(0).toUpperCase() + engine.slice(1) + ' Scraper'); 
    }); 
    $('#create_btn').addClass('d-none');
  });
});

function toggle(heading){
  $('#form-keywords').toggleClass('d-none');
  $('#loading').toggleClass('d-none');
  setHeading(heading);
}

function resume(){
  chrome.runtime.sendMessage({command: 'resume'});
}

function sleep(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

async function loading(callback){
  set('title', 'Please wait...');
  hide('form');
  show('loading');
  await sleep(300);
  callback();
  hide('loading');
}

function resetData(){
	chrome.storage.local.set({keywords: []});
  chrome.storage.local.set({paging_urls: []});
  chrome.storage.local.set({urls: []});
  chrome.storage.local.set({recipes: []});
  chrome.storage.local.set({posts: []});
}

function slugify(string) {
  const a = 'àáâäæãåāăąçćčđďèéêëēėęěğǵḧîïíīįìłḿñńǹňôöòóœøōõőṕŕřßśšşșťțûüùúūǘůűųẃẍÿýžźż·/_,:;'
  const b = 'aaaaaaaaaacccddeeeeeeeegghiiiiiilmnnnnoooooooooprrsssssttuuuuuuuuuwxyyzzz------'
  const p = new RegExp(a.split('').join('|'), 'g')

  return string.toString().toLowerCase()
    .replace(/\s+/g, '-') // Replace spaces with -
    .replace(p, c => b.charAt(a.indexOf(c))) // Replace special characters
    .replace(/&/g, '-and-') // Replace & with 'and'
    .replace(/[^\w\-]+/g, '') // Remove all non-word characters
    .replace(/\-\-+/g, '-') // Replace multiple - with single -
    .replace(/^-+/, '') // Trim - from start of text
    .replace(/-+$/, '') // Trim - from end of text
}


function randomDate(start, end) {
  
  return new Date(start.getTime() + Math.random() * (end.getTime() - start.getTime()));
}

function calculatePostCount(){
	chrome.storage.local.get({recipes: []}, function(result){
		$('#post_count').text(result.recipes.length);
	    
	});
}

function parseHeader(){
  var path = window.location.pathname;
  engine(function(engine){
    $('#engine option').each(function(){
      var target = $(this).val();

      if(target !== 'engine'){

        if(path.includes(target) || engine.includes(target)){
          $(this).attr('selected', 'selected');
        }
      }
    });
  });
}

function parseNav(){
	var path = window.location.pathname;

	$('#navs a').each(function(){
		var href = $(this).attr('data-nav');

		if(path.includes(href)){
			$(this).addClass('disabled');
		}
	});
}

Array.prototype.unique = function() {
  return this.filter(function (value, index, self) { 
    return self.indexOf(value) === index;
  });
}

Array.prototype.sample = function(){
  return this[Math.floor(Math.random()*this.length)];
}

Array.prototype.divideInto = function(n){
	var items = this;
	var results = [];
	const wordsPerLine = Math.ceil(items.length / n);

	for (let line = 0; line < n; line++) {
		var result = [];
		for (let i = 0; i < wordsPerLine; i++) {
			const value = items[i + line * wordsPerLine];
			if (value == undefined) continue; //avoid adding "undefined" values
			result.push(value);
		}
		console.log(result);

		results.push(result);
	}

	return results;
}

function set(id, string){
  show(id);
  $('#'+id).text(string);
}

function setStatus(status){
  showLoading();
	$('#status').removeClass('d-none');
  $('#status').text(status);
}

function setHeading(heading){
  $('#title').text(heading);
}

function showLoading(){
	$('#loading').removeClass('d-none');
}

function hideLoading(){
	$('#loading').addClass('d-none');
}

function showPublishButton(){
	$('#publish_btn').removeClass('d-none');
}

function hidePublishButton(){
	$('#publish_btn').addClass('d-none');
}

function showForm(){
	$('#form').removeClass('d-none');
}

function hideForm(){
	$('#form').addClass('d-none');
}

function show(id){
	$('#'+id).removeClass('d-none');
}

function hide(id){
	$('#'+id).addClass('d-none');
}

function xmlToJson(xml) {
  // Create the return object
  var obj = {};

  if (xml.nodeType == 1) {
    // element
    // do attributes
    if (xml.attributes.length > 0) {
      obj["@attributes"] = {};
      for (var j = 0; j < xml.attributes.length; j++) {
        var attribute = xml.attributes.item(j);
        obj["@attributes"][attribute.nodeName] = attribute.nodeValue;
      }
    }
  } else if (xml.nodeType == 3) {
    // text
    obj = xml.nodeValue;
  }

  // do children
  // If all text nodes inside, get concatenated text from them.
  var textNodes = [].slice.call(xml.childNodes).filter(function(node) {
    return node.nodeType === 3;
  });
  if (xml.hasChildNodes() && xml.childNodes.length === textNodes.length) {
    obj = [].slice.call(xml.childNodes).reduce(function(text, node) {
      return text + node.nodeValue;
    }, "");
  } else if (xml.hasChildNodes()) {
    for (var i = 0; i < xml.childNodes.length; i++) {
      var item = xml.childNodes.item(i);
      var nodeName = item.nodeName;
      if (typeof obj[nodeName] == "undefined") {
        obj[nodeName] = xmlToJson(item);
      } else {
        if (typeof obj[nodeName].push == "undefined") {
          var old = obj[nodeName];
          obj[nodeName] = [];
          obj[nodeName].push(old);
        }
        obj[nodeName].push(xmlToJson(item));
      }
    }
  }
  return obj;
}

function engine(callback){
  chrome.storage.local.get({engine: ''}, function(result){
    var engine = result.engine;
    if(engine.length > 0 && engine !== 'engine'){
      callback(engine)
    }
  });
}

function loadTemplate(templates, callback){
  var template_contents = {};
  engine(function(engine){
    var promises = [];   

    templates.forEach(function(name){
      var promise = $.get('/engine/'+ engine +'/create/'+ name +'.html', function(content){
        template_contents[name] = content;
      });
      promises.push(promise);
    })
    
    $.when.apply($, promises).done(function(){
      callback(template_contents);
    })
    
  });
}

function refreshDownloadBtn(){
  chrome.storage.local.get({ recipes: []}, function(result){
    var recipeCount = result.recipes.length;

    $('#create_btn').removeClass('d-none');
    $('#create_btn span').text(recipeCount);
  });
}

function markInProgress(){
  show('spinner');
  hide('resume_btn');
  show('create_btn');
  refreshDownloadBtn();
}

function markAsDone(){
  setHeading('Scraping finished');
  setStatus('Create posts by clicking button above');
  hide('spinner');
}

function ifQueueExists(callback, reject){
  chrome.storage.local.get({urls: []}, function(result){
    if(result.urls.length > 0){
      console.log(result.urls.length);
      callback();
    }
    else{
      chrome.storage.local.get({paging_urls: []}, function(result){
        if(result.paging_urls.length > 0){
          console.log(result.paging_urls.length);
          callback();
        }
        else{
          chrome.storage.local.get({keywords: []}, function(result){
            if(result.keywords.length > 0){
              console.log(result.keywords.length);
              callback();
            }
            else{
              chrome.storage.local.get({recipes: []}, function(result){
                if(result.recipes.length > 0){
                  reject();                
                }
              });
            }
          });
        }
      });
    }
  });
}