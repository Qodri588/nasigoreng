chrome.runtime.onMessage.addListener(function(request, sender, sendResponse) {
  if (request.command == "scrape"){
    var data = request.data;

    window[data.scraper + '_scraper'](data);
  }
  if(request.command == "resume"){
  	engine(function(engine){
  		var fn = 'resume_' + engine;
  		console.log(fn);
  		window[fn]();
  	});
  }

  if(request.command == "reload"){
    reload();
  }
});
 
function engine(callback){
  chrome.storage.local.get({engine: ''}, function(result){
    var engine = result.engine;
    if(engine.length > 0 && engine !== 'engine'){
      callback(engine)
    }
  });
}

