    <script type="application/ld+json">
{
  "@context": "https://schema.org/", 
  "@type": "Article", 
  "author": {
    "@type": "Person",
    "name": "Louisa Murphy"
  },
  "headline": "Download Full Moon October 31 2020 PNG",
  "datePublished": "2020-02-11",
  "image": http://www.seasky.org/astronomy/assets/images/calendar_legend.jpg,https://moonorganizer.com/wp-content/uploads/2018/12/FULL-MOON-NAMES-2020.png,https://www.moongiant.com/fullmoons/fullmoon2020.jpg,
  "publisher": {
    "@type": "Organization",
    "name": "Louisa Murphy",
    "logo": {
      "@type": "ImageObject",
      "url": "https://via.placeholder.com/512.png?text=L",
      "width": 512,
      "height": 512
    }
  }
}
</script>