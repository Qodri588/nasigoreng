<?php
include "constants.php";

file_put_contents("count.txt","");
$api = array("api_key" => API_KEY);
$data = json_decode(apiakses("keywordsmanager",$api),true);
if($data['error'] == "ok"){
	file_put_contents("keywords.txt",implode("\r\n",$data['result']['keywords_lists']));
	file_put_contents("lang.txt",$data['result']['keywords_language']);
	file_put_contents("id.txt",$data['result']['keywords_id']);
	file_put_contents("label.txt",$data['result']['keywords_label']);
    file_put_contents("count.txt",count($data['result']['keywords_lists']));

	print_r("STARTED\r\n");
}else{
	echo $data['reason']."\r\n";
}
