<div class="d-block p-4">
	<center>
		<!-- BOTTOM BANNER ADS -->
	</center>
</div>