<?php
// prevent browser
if(PHP_SAPI !== 'cli'){ die; }
require 'constants.php';
require 'vendor/autoload.php';
require 'helpers.php';

echo "=> generating xml for blogspot\n";

$list_file = keywords();

shuffle($list_file);

$split = ARTICLE_PER_XML;
$apikey = API_KEY;

$list = array_chunk($list_file,$split);

foreach ($list as $key => $sublist)
{
	$pno = $key + 1;
	
	$content = export('export.blogspot', ['keywords' => $sublist,'argv' => $argv], false);
	$name = file_get_contents("label.txt");
	$api = array("api_key" => $apikey,
				 "data" => $content,
				 "name"=>"blogger-".$name."-".time().".xml",
				 "id" => file_get_contents("id.txt"));

	$data = json_decode(apiakses("keywordsfeedback",$api),true);

	if($data['error'] == "ok"){
		echo "Done!\r\n";
	}else{
		echo $data['reason'];
	}
}
