#!/bin/bash

while true
do

php start.php

value=$(<count.txt)

if [ ! -z $value ]
then
        php clear-data.php

        bahasa=$(<lang.txt)
		echo $bahasa
		
        php import-kw.php keywords.txt $bahasa 5000
        php generate-sitemap.php

        php export-blogspot.php
		
	echo sleep 5 menit dulu
        sleep 300
else
        echo tidur 1800 detik
        sleep 1800
fi

done
